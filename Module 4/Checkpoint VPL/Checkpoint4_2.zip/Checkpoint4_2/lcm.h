// lcm.h
#ifndef LCM_H
#define LCM_H

int lcm(int a, int b);

#endif
