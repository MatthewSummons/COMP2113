#include <iostream>
#include <string>

/**
 * A morse code decoder.
 */

using namespace std;

// IMPORTANT:  Do NOT change any of the function headers
//             It means that you will need to use the function headers as is
//             You may add other functions wherever appropriate


/**
 * Decode the morse code `s` and return the text character
 */
string morseCodeToText(string s) {
	string text = "";

	return text;
}


int main()
{
		string s;
		cin >> s;
		cout << morseCodeToText(s) << '\n';

    return 0;
}
